package com.everyparking.user.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/test")
public class TestController {

    @RequestMapping("/test1")
    public ModelAndView test1() {

        return new ModelAndView("/main/content");
    }

    @RequestMapping("/test2")
    public ModelAndView test2() {

        return new ModelAndView("/main/home");
    }

    @RequestMapping("/test3")
    public ModelAndView test3() {

        return new ModelAndView("/main/list");
    }

    @RequestMapping("/test4")
    public ModelAndView test4() {

        return new ModelAndView("/main/map");
    }

    @RequestMapping("/test5")
    public ModelAndView test5() {

        return new ModelAndView("/mypage/myinfo/confirmPw");
    }

    @RequestMapping("/test6")
    public ModelAndView test6() {

        return new ModelAndView("/mypage/myinfo/goodBye");
    }

    @RequestMapping("/test7")
    public ModelAndView test7() {

        return new ModelAndView("/mypage/myinfo/UpdateComplete");
    }

    @RequestMapping("/test8")
    public ModelAndView test8() {

        return new ModelAndView("/mypage/myinfo/updatePage");
    }

    @RequestMapping("/test9")
    public ModelAndView test9() {

        return new ModelAndView("/mypage/reservation/checkUsageCancelPage");
    }

    @RequestMapping("/test10")
    public ModelAndView test10() {

        return new ModelAndView("/mypage/reservation/checkUsageDetailsPage");
    }

    @RequestMapping("/test11")
    public ModelAndView test11() {

        return new ModelAndView("/mypage/review/checkUsageReviewListPage");
    }

    @RequestMapping("/test12")
    public ModelAndView test12() {

        return new ModelAndView("/mypage/review/checkUsageReviewPage");
    }

    @RequestMapping("/test13")
    public ModelAndView test13() {

        return new ModelAndView("/mypage/review/write");
    }

    @RequestMapping("/test14")
    public ModelAndView test14() {

        return new ModelAndView("/operation/notice/content");
    }

    @RequestMapping("/test15")
    public ModelAndView test15() {

        return new ModelAndView("/operation/notice/list");
    }

    @RequestMapping("/test16")
    public ModelAndView test16() {

        return new ModelAndView("/operation/qna/list");
    }

    @RequestMapping("/test17")
    public ModelAndView test17() {

        return new ModelAndView("/operation/qna/reply");
    }

    @RequestMapping("/test18")
    public ModelAndView test18() {

        return new ModelAndView("/operation/qna/write");
    }
}




